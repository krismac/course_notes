package com.codeclan.example.WhiskyTracker.repositories.WhiskyRepository;


public class WhiskyRepositoryImpl implements WhiskyRepositoryCustom {
}
