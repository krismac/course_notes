package com.codeclan.example.WhiskyTracker.repositories.DistilleryRepository;

public interface DistilleryRepositoryCustom {
}
