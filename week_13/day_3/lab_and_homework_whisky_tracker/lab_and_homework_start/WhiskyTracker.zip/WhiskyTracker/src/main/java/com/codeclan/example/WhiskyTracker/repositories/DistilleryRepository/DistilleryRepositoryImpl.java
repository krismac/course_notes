package com.codeclan.example.WhiskyTracker.repositories.DistilleryRepository;

public class DistilleryRepositoryImpl implements DistilleryRepositoryCustom {
}
