package com.codeclan.example.WhiskyTracker.repositories.WhiskyRepository;

public interface WhiskyRepositoryCustom {
}
